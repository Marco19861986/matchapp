export type PlayerPosition = 'goalkeeper' | 'player';
export type TeamType = 'home' | 'away';

export interface PlayerStats {
  gamesPlayed: number;
  goals: number;
  assists: number;
  averageRating: number;
}

export interface Player {
  id: string;
  name: string;
  position: PlayerPosition;
  team?: TeamType;
  stats: PlayerStats;
  lastUpdate?: string;
}

export interface PlayerLimits {
  goalkeeper: number;
  player: number;
}

export const PLAYER_LIMITS: PlayerLimits = {
  goalkeeper: 6,
  player: 28,
};

export const TOTAL_PLAYERS = 34;

export const createDefaultStats = (position: PlayerPosition): PlayerStats => ({
  gamesPlayed: 0,
  goals: 0,
  assists: 0,
  averageRating: 0
});