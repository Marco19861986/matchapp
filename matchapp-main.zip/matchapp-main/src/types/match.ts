import { Player } from "./player";

export interface MatchPlayer extends Player {
  rating?: number;
  goals: number;
  assists: number;
}

export interface Match {
  id: string;
  date: Date;
  homeScore: number;
  awayScore: number;
  players: MatchPlayer[];
}

export const createEmptyMatch = (date: Date): Match => ({
  id: crypto.randomUUID(),
  date,
  homeScore: 0,
  awayScore: 0,
  players: []
});