import { useState } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Match, createEmptyMatch } from "@/types/match";
import { useNavigate } from "react-router-dom";
import { addDays, isWednesday, isSunday, startOfDay } from "date-fns";
import { Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Matches = () => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [matches, setMatches] = useState<Match[]>(() => {
    const savedMatches = localStorage.getItem('football-manager-matches');
    return savedMatches ? JSON.parse(savedMatches, (key, value) => {
      if (key === 'date') return new Date(value);
      return value;
    }) : [];
  });
  const navigate = useNavigate();
  const { toast } = useToast();

  const isMatchDay = (date: Date) => {
    return isWednesday(date) || isSunday(date);
  };

  const handleDateSelect = (date: Date | undefined) => {
    if (!date || !isMatchDay(date)) return;
    setSelectedDate(date);
  };

  const handleCreateMatch = () => {
    if (!selectedDate) return;
    
    const newMatch = createEmptyMatch(selectedDate);
    setMatches(prev => {
      const updated = [...prev, newMatch];
      localStorage.setItem('football-manager-matches', JSON.stringify(updated));
      return updated;
    });
    navigate(`/partidos/${newMatch.id}`);
  };

  const handleDeleteMatch = () => {
    if (!selectedDate) return;
    
    const matchToDelete = getMatchForDate(selectedDate);
    if (!matchToDelete) return;

    setMatches(prev => {
      const updated = prev.filter(m => m.id !== matchToDelete.id);
      localStorage.setItem('football-manager-matches', JSON.stringify(updated));
      return updated;
    });

    toast({
      title: "Partido eliminado",
      description: "Se han borrado todos los datos del partido",
    });
  };

  const getMatchForDate = (date: Date) => {
    return matches.find(m => 
      startOfDay(new Date(m.date)).getTime() === startOfDay(date).getTime()
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Calendario de Partidos</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center space-y-4">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={handleDateSelect}
              disabled={(date) => !isMatchDay(date)}
              modifiers={{
                matchDay: (date) => isMatchDay(date),
                hasMatch: (date) => Boolean(getMatchForDate(date))
              }}
              modifiersClassNames={{
                matchDay: "bg-blue-100",
                hasMatch: "bg-green-200"
              }}
            />
            <div className="flex gap-2 items-center">
              {selectedDate && !getMatchForDate(selectedDate) && (
                <Button onClick={handleCreateMatch}>
                  Crear Partido
                </Button>
              )}
              {selectedDate && getMatchForDate(selectedDate) && (
                <>
                  <Button 
                    onClick={() => navigate(`/partidos/${getMatchForDate(selectedDate)?.id}`)}
                  >
                    Ver Partido
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={handleDeleteMatch}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Matches;