import { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Match, MatchPlayer } from "@/types/match";
import { Player, TeamType } from "@/types/player";
import { ScoreInput } from "@/components/ScoreInput";
import { useToast } from "@/components/ui/use-toast";
import { Trophy } from "lucide-react";
import html2canvas from "html2canvas";

interface MatchDetailProps {
  players: Player[];
  onUpdatePlayers: (players: Player[]) => void;
}

const MatchDetail = ({ players, onUpdatePlayers }: MatchDetailProps) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [match, setMatch] = useState<Match | null>(null);
  const [matches, setMatches] = useState<Match[]>([]);
  const [homeTeamColor, setHomeTeamColor] = useState("rojo");
  const [awayTeamColor, setAwayTeamColor] = useState("azul");
  const fieldRef = useRef<HTMLDivElement>(null);
  const [fieldPlayers, setFieldPlayers] = useState<{ [key: string]: Player }>({});

  useEffect(() => {
    const savedMatches = localStorage.getItem('football-manager-matches');
    if (savedMatches) {
      const parsed = JSON.parse(savedMatches, (key, value) => {
        if (key === 'date') return new Date(value);
        return value;
      });
      setMatches(parsed);
      const foundMatch = parsed.find((m: Match) => m.id === id);
      if (foundMatch) {
        setMatch(foundMatch);
      }
    }
  }, [id]);

  const handleScoreChange = (homeScore: number, awayScore: number) => {
    if (!match) return;
    setMatch({ ...match, homeScore, awayScore });
  };

  const handlePlayerSelect = (player: Player) => {
    if (!match) return;
    
    setMatch(prev => {
      if (!prev) return prev;
      const isPlayerInMatch = prev.players.some(p => p.id === player.id);
      
      if (isPlayerInMatch) {
        return {
          ...prev,
          players: prev.players.filter(p => p.id !== player.id)
        };
      }

      const homeTeamCount = prev.players.filter(p => p.team === 'home').length;
      const awayTeamCount = prev.players.filter(p => p.team === 'away').length;

      let team: TeamType;
      if (homeTeamCount < 8) {
        team = 'home';
      } else if (awayTeamCount < 8) {
        team = 'away';
      } else {
        toast({
          title: "Error",
          description: "Ambos equipos ya tienen 8 jugadores",
          variant: "destructive",
        });
        return prev;
      }

      return {
        ...prev,
        players: [...prev.players, { ...player, team, goals: 0, assists: 0 }]
      };
    });
  };

  const handlePlayerStatsChange = (playerId: string, field: keyof MatchPlayer, value: number) => {
    if (!match) return;
    setMatch(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        players: prev.players.map(p => 
          p.id === playerId ? { ...p, [field]: value } : p
        )
      };
    });
  };

  const handleSave = () => {
    if (!match) return;

    const updatedMatches = matches.map(m => m.id === match.id ? match : m);
    localStorage.setItem('football-manager-matches', JSON.stringify(updatedMatches));

    const updatedPlayers = players.map(player => {
      const matchParticipation = match.players.find(p => p.id === player.id);
      if (!matchParticipation) return player;

      const playerMatches = updatedMatches.filter(m => 
        m.players.some(p => p.id === player.id)
      );

      const totalGames = playerMatches.length;
      const totalGoals = playerMatches.reduce((sum, m) => 
        sum + (m.players.find(p => p.id === player.id)?.goals || 0), 0
      );
      const totalAssists = playerMatches.reduce((sum, m) => 
        sum + (m.players.find(p => p.id === player.id)?.assists || 0), 0
      );
      const totalRating = playerMatches.reduce((sum, m) => 
        sum + (m.players.find(p => p.id === player.id)?.rating || 0), 0
      );

      return {
        ...player,
        stats: {
          gamesPlayed: totalGames,
          goals: totalGoals,
          assists: totalAssists,
          averageRating: totalGames > 0 ? totalRating / totalGames : 0
        }
      };
    });

    onUpdatePlayers(updatedPlayers);
    toast({
      title: "Partido guardado",
      description: "Los cambios han sido guardados correctamente",
    });
  };

  const getMatchSummary = () => {
    if (!match) return null;
    
    const homeTeamPlayers = match.players.filter(p => p.team === 'home');
    const awayTeamPlayers = match.players.filter(p => p.team === 'away');
    
    const homeGoalScorers = homeTeamPlayers
      .filter(p => p.goals > 0)
      .map(p => `${p.name} (${p.goals})`)
      .join(', ');
    
    const awayGoalScorers = awayTeamPlayers
      .filter(p => p.goals > 0)
      .map(p => `${p.name} (${p.goals})`)
      .join(', ');
    
    const homeAssists = homeTeamPlayers
      .filter(p => p.assists > 0)
      .map(p => `${p.name} (${p.assists})`)
      .join(', ');
    
    const awayAssists = awayTeamPlayers
      .filter(p => p.assists > 0)
      .map(p => `${p.name} (${p.assists})`)
      .join(', ');

    return {
      homeGoalScorers,
      awayGoalScorers,
      homeAssists,
      awayAssists
    };
  };

  const getManOfTheMatch = () => {
    if (!match) return null;
    
    const playerWithHighestRating = match.players.reduce((highest, current) => {
      if (!highest || (current.rating || 0) > (highest.rating || 0)) {
        return current;
      }
      return highest;
    }, null as MatchPlayer | null);

    return playerWithHighestRating;
  };

  const handleShareWhatsApp = async () => {
    if (!fieldRef.current) {
      toast({
        title: "Error",
        description: "No se encontró el campo de fútbol.",
        variant: "destructive",
      });
      return;
    }

    try {
      const canvas = await html2canvas(fieldRef.current);
      const imageBase64 = canvas.toDataURL("image/png").split(",")[1];

      const clientId = "9d5e197db84de1c"; // Imgur Client ID
      const response = await fetch("https://api.imgur.com/3/image", {
        method: "POST",
        headers: {
          Authorization: `Client-ID ${clientId}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ image: imageBase64 }),
      });

      const data = await response.json();

      if (data.success) {
        const imageUrl = data.data.link;
        
        // Usar la fecha del partido en lugar de la fecha actual
        const matchDate = match.date.toLocaleDateString('es-ES', {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        });

        // Determinar la hora del partido basado en el día
        const isWednesday = match.date.getDay() === 3;
        const matchTime = isWednesday ? "22:00" : "09:00";

        const formatPlayerList = (team: 'home' | 'away') => {
          return Object.entries(fieldPlayers)
            .filter(([key]) => key.startsWith(team))
            .map(([key, player]) => {
              const position = key.includes('gk') ? '🧤 Portero' :
                             key.includes('def') ? '👟 Defensa' :
                             key.includes('mid') ? '👟 Mediocampista' :
                             '👟 Delantero';
              return `- ${position}: ${(player as Player).name}`;
            })
            .join('\n');
        };

        const message = encodeURIComponent(
          `🏆 *ALINEACIÓN PARA EL PARTIDO*\n\n` +
          `📅 *Fecha:* ${matchDate}\n` +
          `⏰ *Hora:* ${matchTime}\n\n` +
          `👕 *Equipo ${homeTeamColor}:*\n${formatPlayerList('home') || 'Sin jugadores'}\n\n` +
          `👕 *Equipo ${awayTeamColor}:*\n${formatPlayerList('away') || 'Sin jugadores'}\n\n` +
          `📸 *Alineación:*\n${imageUrl}`
        );

        window.open(`https://wa.me/?text=${message}`, "_blank");
        
        toast({
          title: "¡Imagen compartida!",
          description: "La alineación se ha preparado para compartir en WhatsApp",
        });
      } else {
        toast({
          title: "Error",
          description: "No se pudo subir la imagen a Imgur.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error al capturar o subir la imagen:", error);
      toast({
        title: "Error",
        description: "Hubo un error al procesar la imagen",
        variant: "destructive",
      });
    }
  };

  if (!match) return null;

  const homeTeamPlayers = match.players.filter(p => p.team === 'home');
  const awayTeamPlayers = match.players.filter(p => p.team === 'away');
  const matchSummary = getMatchSummary();
  const manOfTheMatch = getManOfTheMatch();

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>
              Partido del {match.date.toLocaleDateString()}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Score Display */}
            <div id="campo-futbol" ref={fieldRef} className="bg-white rounded-xl shadow-lg p-6 mb-8">
              <div className="flex items-center justify-center gap-8 p-6 bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl">
                <div className="flex flex-col items-center gap-3">
                  <div className="w-4 h-4 rounded-full bg-team-red" />
                  <span className="text-xl font-medium">Equipo {homeTeamColor}</span>
                </div>
                <div className="flex items-center gap-6">
                  <span className="text-6xl font-bold text-team-red">{match.homeScore}</span>
                  <span className="text-4xl font-medium text-gray-400">-</span>
                  <span className="text-6xl font-bold text-team-blue">{match.awayScore}</span>
                </div>
                <div className="flex flex-col items-center gap-3">
                  <div className="w-4 h-4 rounded-full bg-team-blue" />
                  <span className="text-xl font-medium">Equipo {awayTeamColor}</span>
                </div>
              </div>
            </div>

            {/* Share Button */}
            <div className="flex justify-center">
              <Button 
                onClick={handleShareWhatsApp}
                className="bg-green-500 hover:bg-green-600"
              >
                Compartir en WhatsApp
              </Button>
            </div>

            {/* Match Summary with improved styling */}
            {matchSummary && (
              <Card className="bg-white shadow-md">
                <CardContent className="p-6">
                  <div className="grid grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <h4 className="text-xl font-semibold text-team-red capitalize">Equipo {homeTeamColor}</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">⚽</span>
                          <div>
                            <span className="font-medium">Goles:</span>
                            <p className="text-lg">{matchSummary.homeGoalScorers || 'Ninguno'}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">🎯</span>
                          <div>
                            <span className="font-medium">Asistencias:</span>
                            <p className="text-lg">{matchSummary.homeAssists || 'Ninguna'}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h4 className="text-xl font-semibold text-team-blue capitalize">Equipo {awayTeamColor}</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">⚽</span>
                          <div>
                            <span className="font-medium">Goles:</span>
                            <p className="text-lg">{matchSummary.awayGoalScorers || 'Ninguno'}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">🎯</span>
                          <div>
                            <span className="font-medium">Asistencias:</span>
                            <p className="text-lg">{matchSummary.awayAssists || 'Ninguna'}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Man of the Match with improved styling */}
            {manOfTheMatch && manOfTheMatch.rating && (
              <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-center gap-4">
                    <Trophy className="w-8 h-8 text-yellow-600" />
                    <div className="text-center">
                      <h4 className="text-xl font-bold text-yellow-800">Jugador del Partido</h4>
                      <p className="text-lg">
                        {manOfTheMatch.name} - Calificación: {manOfTheMatch.rating}/10
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Equipo Local */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Equipo {homeTeamColor} ({homeTeamPlayers.length}/8)</h3>
                <div className="space-y-4">
                  {homeTeamPlayers.map(player => (
                    <Card key={player.id}>
                      <CardContent className="pt-6 space-y-4">
                        <h4 className="font-semibold">{player.name}</h4>
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Label htmlFor={`goals-${player.id}`}>Goles:</Label>
                            <Input
                              id={`goals-${player.id}`}
                              type="number"
                              min="0"
                              value={player.goals}
                              onChange={(e) => handlePlayerStatsChange(player.id, 'goals', parseInt(e.target.value) || 0)}
                              className="w-20"
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <Label htmlFor={`assists-${player.id}`}>Asistencias:</Label>
                            <Input
                              id={`assists-${player.id}`}
                              type="number"
                              min="0"
                              value={player.assists}
                              onChange={(e) => handlePlayerStatsChange(player.id, 'assists', parseInt(e.target.value) || 0)}
                              className="w-20"
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <Label htmlFor={`rating-${player.id}`}>Nota (1-10):</Label>
                            <Input
                              id={`rating-${player.id}`}
                              type="number"
                              min="1"
                              max="10"
                              value={player.rating || ''}
                              onChange={(e) => handlePlayerStatsChange(player.id, 'rating', parseInt(e.target.value) || 0)}
                              className="w-20"
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Equipo Visitante */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Equipo {awayTeamColor} ({awayTeamPlayers.length}/8)</h3>
                <div className="space-y-4">
                  {awayTeamPlayers.map(player => (
                    <Card key={player.id}>
                      <CardContent className="pt-6 space-y-4">
                        <h4 className="font-semibold">{player.name}</h4>
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Label htmlFor={`goals-${player.id}`}>Goles:</Label>
                            <Input
                              id={`goals-${player.id}`}
                              type="number"
                              min="0"
                              value={player.goals}
                              onChange={(e) => handlePlayerStatsChange(player.id, 'goals', parseInt(e.target.value) || 0)}
                              className="w-20"
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <Label htmlFor={`assists-${player.id}`}>Asistencias:</Label>
                            <Input
                              id={`assists-${player.id}`}
                              type="number"
                              min="0"
                              value={player.assists}
                              onChange={(e) => handlePlayerStatsChange(player.id, 'assists', parseInt(e.target.value) || 0)}
                              className="w-20"
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <Label htmlFor={`rating-${player.id}`}>Nota (1-10):</Label>
                            <Input
                              id={`rating-${player.id}`}
                              type="number"
                              min="1"
                              max="10"
                              value={player.rating || ''}
                              onChange={(e) => handlePlayerStatsChange(player.id, 'rating', parseInt(e.target.value) || 0)}
                              className="w-20"
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-4">
              <Button variant="outline" onClick={() => navigate('/partidos')}>
                Cancelar
              </Button>
              <Button onClick={handleSave}>
                Guardar
              </Button>
            </div>

            <div className="space-y-4 mt-8 pt-8 border-t">
              <h3 className="text-lg font-semibold">Jugadores Disponibles</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {players.map(player => (
                  <Button
                    key={player.id}
                    variant={match.players.some(p => p.id === player.id) ? "default" : "outline"}
                    onClick={() => handlePlayerSelect(player)}
                  >
                    {player.name}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MatchDetail;
