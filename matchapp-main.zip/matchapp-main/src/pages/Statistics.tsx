import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Player } from "@/types/player";
import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface StatisticsProps {
  players: Player[];
  onUpdatePlayerName: (playerId: string, newName: string) => void;
}

type SortCriteria = "rating" | "goals" | "assists" | "gamesPlayed";

const Statistics = ({ players, onUpdatePlayerName }: StatisticsProps) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState<SortCriteria>("rating");

  const sortPlayers = (players: Player[], criteria: SortCriteria) => {
    return [...players].sort((a, b) => {
      switch (criteria) {
        case "rating":
          if (!a.stats.averageRating && !b.stats.averageRating) return 0;
          if (!a.stats.averageRating) return 1;
          if (!b.stats.averageRating) return -1;
          return b.stats.averageRating - a.stats.averageRating;
        case "goals":
          return b.stats.goals - a.stats.goals;
        case "assists":
          return b.stats.assists - a.stats.assists;
        case "gamesPlayed":
          return b.stats.gamesPlayed - a.stats.gamesPlayed;
        default:
          return 0;
      }
    });
  };

  const filteredPlayers = sortPlayers(
    players.filter(player =>
      player.name.toLowerCase().includes(searchTerm.toLowerCase())
    ),
    sortBy
  );

  const getStatValue = (player: Player, criteria: SortCriteria) => {
    switch (criteria) {
      case "rating":
        return player.stats.averageRating?.toFixed(1) || "0.0";
      case "goals":
        return player.stats.goals.toString();
      case "assists":
        return player.stats.assists.toString();
      case "gamesPlayed":
        return player.stats.gamesPlayed.toString();
    }
  };

  const getStatLabel = (criteria: SortCriteria) => {
    switch (criteria) {
      case "rating":
        return "Nota media";
      case "goals":
        return "Goles";
      case "assists":
        return "Asistencias";
      case "gamesPlayed":
        return "Partidos jugados";
    }
  };

  return (
    <div className="min-h-screen bg-app-background p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-heading">
              Estadísticas de Jugadores
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <Input
                  placeholder="Buscar jugador..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="max-w-sm"
                />
                <Select
                  value={sortBy}
                  onValueChange={(value: SortCriteria) => setSortBy(value)}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Ordenar por..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rating">Nota media</SelectItem>
                    <SelectItem value="goals">Goles</SelectItem>
                    <SelectItem value="assists">Asistencias</SelectItem>
                    <SelectItem value="gamesPlayed">Partidos jugados</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredPlayers.map(player => (
                  <Card key={player.id}>
                    <CardHeader>
                      <Input
                        value={player.name}
                        onChange={(e) => onUpdatePlayerName(player.id, e.target.value)}
                        className="font-semibold"
                      />
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between font-medium">
                          <span>{getStatLabel(sortBy)}:</span>
                          <span className="text-primary">{getStatValue(player, sortBy)}</span>
                        </div>
                        <div className="space-y-1 text-sm text-muted-foreground">
                          <div className="flex justify-between">
                            <span>Partidos jugados:</span>
                            <span>{player.stats.gamesPlayed}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Goles:</span>
                            <span>{player.stats.goals}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Asistencias:</span>
                            <span>{player.stats.assists}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Promedio nota:</span>
                            <span>{player.stats.averageRating?.toFixed(1) || '0.0'}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Statistics;