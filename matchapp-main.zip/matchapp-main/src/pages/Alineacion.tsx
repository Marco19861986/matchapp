import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FootballField } from "@/components/FootballField";
import { TeamColorSelector } from "@/components/TeamColorSelector";
import { PlayerList } from "@/components/PlayerList";
import { Player } from "@/types/player";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Share, RefreshCw } from "lucide-react";
import html2canvas from "html2canvas";

interface AlineacionProps {
  players: Player[];
  onUpdatePlayers: (players: Player[]) => void;
  onUpdatePlayerName: (playerId: string, name: string) => void;
}

const Alineacion = ({ players, onUpdatePlayers, onUpdatePlayerName }: AlineacionProps) => {
  const [homeTeamColor, setHomeTeamColor] = useState("red");
  const [awayTeamColor, setAwayTeamColor] = useState("blue");
  const [fieldPlayers, setFieldPlayers] = useState<{ [key: string]: Player }>({});
  const [selectedPosition, setSelectedPosition] = useState<string | null>(null);
  const { toast } = useToast();
  const fieldRef = useRef<HTMLDivElement>(null);

  const handlePlayerSelect = (player: Player) => {
    if (selectedPosition) {
      setFieldPlayers(prev => ({
        ...prev,
        [selectedPosition]: { ...player }
      }));
      
      toast({
        title: "Jugador reemplazado",
        description: `${player.name} ha reemplazado la posición anterior`,
      });
      
      setSelectedPosition(null);
      return;
    }

    const awayTeamComplete = Object.keys(fieldPlayers).filter(key => key.startsWith('away')).length === 8;
    const team = awayTeamComplete ? 'home' : 'away';

    let position = '';
    const teamPlayers = Object.entries(fieldPlayers).filter(([key]) => key.startsWith(team));

    if (teamPlayers.length === 0) {
      position = `${team}-gk`;
    } else if (teamPlayers.length <= 3) {
      const defNum = teamPlayers.filter(([key]) => key.includes('def')).length + 1;
      position = `${team}-def-${defNum}`;
    } else if (teamPlayers.length <= 6) {
      const midNum = teamPlayers.filter(([key]) => key.includes('mid')).length + 1;
      position = `${team}-mid-${midNum}`;
    } else if (teamPlayers.length === 7) {
      position = `${team}-fw`;
    }

    if (position) {
      setFieldPlayers(prev => ({
        ...prev,
        [position]: { ...player }
      }));

      const teamName = team === 'away' ? 'Azules' : 'Rojos';
      const positionName = position.includes('gk') ? 'portero' : 
                          position.includes('def') ? 'defensa' : 
                          position.includes('mid') ? 'mediocampista' : 
                          'delantero';
      
      toast({
        title: `Jugador asignado al equipo ${teamName}`,
        description: `${player.name} ha sido asignado como ${positionName}`,
      });

      if (Object.keys(fieldPlayers).length + 1 === 16) {
        toast({
          title: "¡Equipos completos!",
          description: "Todos los jugadores han sido asignados",
        });
      }
    }
  };

  const handleFieldPlayerClick = (position: string, player: Player) => {
    setSelectedPosition(position);
    const positionName = position.includes('gk') ? 'portero' : 
                        position.includes('def') ? 'defensa' : 
                        position.includes('mid') ? 'mediocampista' : 
                        'delantero';
    
    toast({
      title: `Jugador seleccionado para reemplazo`,
      description: `Has seleccionado a ${player.name} en la posición de ${positionName}. Elige otro jugador de la lista para reemplazarlo.`,
    });
  };

  const handleAddPlayer = (newPlayer: Player) => {
    const updatedPlayers = [...players, newPlayer];
    onUpdatePlayers(updatedPlayers);
    toast({
      title: "Jugador añadido",
      description: "Se ha añadido un nuevo jugador a la lista",
    });
  };

  const handleReset = () => {
    setFieldPlayers({});
    setSelectedPosition(null);
    toast({
      title: "Equipos reiniciados",
      description: "Se han eliminado todas las asignaciones de jugadores",
    });
  };

  const handleShareWhatsApp = async () => {
    if (!fieldRef.current) {
      toast({
        title: "Error",
        description: "No se encontró el campo de fútbol.",
        variant: "destructive",
      });
      return;
    }

    try {
      const canvas = await html2canvas(fieldRef.current);
      const imageBase64 = canvas.toDataURL("image/png").split(",")[1];

      const clientId = "9d5e197db84de1c"; // Imgur Client ID
      const response = await fetch("https://api.imgur.com/3/image", {
        method: "POST",
        headers: {
          Authorization: `Client-ID ${clientId}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ image: imageBase64 }),
      });

      const data = await response.json();

      if (data.success) {
        const imageUrl = data.data.link;
        
        // Formatear la fecha actual
        const now = new Date();
        const matchDate = now.toLocaleDateString('es-ES', {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        });

        // Determinar la hora según el día
        const isWednesday = now.getDay() === 3;
        const matchTime = isWednesday ? "22:00" : "09:00";

        // Obtener la lista de jugadores por equipo con sus posiciones
        const formatPlayerList = (team: 'home' | 'away') => {
          return Object.entries(fieldPlayers)
            .filter(([key]) => key.startsWith(team))
            .map(([key, player]) => {
              const position = key.includes('gk') ? '🧤 Portero' :
                             key.includes('def') ? '👟 Defensa' :
                             key.includes('mid') ? '👟 Mediocampista' :
                             '👟 Delantero';
              return `- ${position}: ${(player as Player).name}`;
            })
            .join('\n');
        };

        const message = encodeURIComponent(
          `🏆 *ALINEACIÓN PARA EL PARTIDO*\n\n` +
          `📅 *Fecha:* ${matchDate}\n` +
          `⏰ *Hora:* ${matchTime}\n\n` +
          `👕 *Equipo ${homeTeamColor}:*\n${formatPlayerList('home') || 'Sin jugadores'}\n\n` +
          `👕 *Equipo ${awayTeamColor}:*\n${formatPlayerList('away') || 'Sin jugadores'}\n\n` +
          `📸 *Alineación:*\n${imageUrl}`
        );

        window.open(`https://wa.me/?text=${message}`, "_blank");
        
        toast({
          title: "¡Imagen compartida!",
          description: "La alineación se ha preparado para compartir en WhatsApp",
        });
      } else {
        toast({
          title: "Error",
          description: "No se pudo subir la imagen a Imgur.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error al capturar o subir la imagen:", error);
      toast({
        title: "Error",
        description: "Hubo un error al procesar la imagen",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-heading">
              Alineación
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="flex flex-wrap gap-4">
                  <TeamColorSelector
                    team="home"
                    value={homeTeamColor}
                    onChange={setHomeTeamColor}
                  />
                  <TeamColorSelector
                    team="away"
                    value={awayTeamColor}
                    onChange={setAwayTeamColor}
                  />
                </div>
                <div ref={fieldRef}>
                  <FootballField
                    homeTeamColor={homeTeamColor}
                    awayTeamColor={awayTeamColor}
                    players={fieldPlayers}
                    onResetPlayers={handleReset}
                    onPlayerClick={handleFieldPlayerClick}
                  />
                </div>
                <div className="flex justify-center">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleReset}
                    className="w-full max-w-xs"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Reiniciar
                  </Button>
                </div>
                <div className="space-y-2">
                  <Button 
                    onClick={handleShareWhatsApp}
                    className="w-full bg-green-600 hover:bg-green-700 text-white"
                  >
                    <Share className="w-4 h-4 mr-2" />
                    Compartir en WhatsApp
                  </Button>
                </div>
              </div>
              <PlayerList
                players={players}
                onPlayerSelect={handlePlayerSelect}
                onReset={handleReset}
                onAddPlayer={handleAddPlayer}
                onUpdatePlayerName={onUpdatePlayerName}
                selectedPlayers={fieldPlayers}
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Alineacion;
