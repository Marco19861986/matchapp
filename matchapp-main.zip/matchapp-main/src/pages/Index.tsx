import { MatchBoxes } from "@/components/MatchBoxes";
import { TopPlayers } from "@/components/TopPlayers";
import { Match } from "@/types/match";
import { useEffect, useState } from "react";
import { Player } from "@/types/player";
import { useToast } from "@/components/ui/use-toast";
import { PlayerList } from "@/components/PlayerList";

interface IndexProps {
  players: Player[];
  onUpdatePlayers: (players: Player[]) => void;
  onUpdatePlayerName: (playerId: string, name: string) => void;
}

const Index = ({ players, onUpdatePlayers, onUpdatePlayerName }: IndexProps) => {
  const [lastMatch, setLastMatch] = useState<Match | undefined>();
  const { toast } = useToast();

  useEffect(() => {
    // Cargar el último partido
    const savedMatches = localStorage.getItem('football-manager-matches');
    if (savedMatches) {
      const matches: Match[] = JSON.parse(savedMatches, (key, value) => {
        if (key === 'date') return new Date(value);
        return value;
      });
      
      // Get the most recent match
      const sortedMatches = matches.sort((a, b) => 
        new Date(b.date).getTime() - new Date(a.date).getTime()
      );
      setLastMatch(sortedMatches[0]);
    }
  }, []);

  const handleAddPlayer = (newPlayer: Player) => {
    const updatedPlayers = [...players, newPlayer];
    onUpdatePlayers(updatedPlayers);
    toast({
      title: "Jugador añadido",
      description: "Se ha añadido un nuevo jugador al equipo",
    });
  };

  const handleReset = () => {
    onUpdatePlayers([]);
    toast({
      title: "Lista reiniciada",
      description: "Se ha reiniciado la lista de jugadores",
    });
  };

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <MatchBoxes lastMatch={lastMatch} />
      <TopPlayers players={players} />
      {/* Lista de jugadores oculta pero manteniendo la funcionalidad */}
      <div className="hidden">
        <PlayerList 
          players={players}
          onPlayerSelect={() => {}}
          onReset={handleReset}
          onAddPlayer={handleAddPlayer}
          onUpdatePlayerName={onUpdatePlayerName}
          selectedPlayers={{}}
        />
      </div>
    </div>
  );
};

export default Index;