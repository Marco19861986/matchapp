import { Input } from "@/components/ui/input";
import { TeamColorSelector } from "@/components/TeamColorSelector";
import { useIsMobile } from "@/hooks/use-mobile";

interface ScoreInputProps {
  homeScore: number;
  awayScore: number;
  onHomeScoreChange: (value: number) => void;
  onAwayScoreChange: (value: number) => void;
  homeTeamColor: string;
  awayTeamColor: string;
  onHomeTeamColorChange: (value: string) => void;
  onAwayTeamColorChange: (value: string) => void;
}

export const ScoreInput = ({
  homeScore,
  awayScore,
  onHomeScoreChange,
  onAwayScoreChange,
  homeTeamColor,
  awayTeamColor,
  onHomeTeamColorChange,
  onAwayTeamColorChange,
}: ScoreInputProps) => {
  const isMobile = useIsMobile();

  return (
    <div className="flex flex-col gap-4 p-4 bg-white rounded-lg shadow-sm">
      <div className="flex items-center justify-center gap-4">
        <TeamColorSelector
          team="home"
          value={homeTeamColor}
          onChange={onHomeTeamColorChange}
          compact={true}
        />
        <Input
          id="homeScore"
          type="number"
          min="0"
          value={homeScore}
          onChange={(e) => onHomeScoreChange(parseInt(e.target.value) || 0)}
          className="w-16 text-center"
        />
      </div>
      <div className="flex items-center justify-center">
        <span className="text-xl font-bold">-</span>
      </div>
      <div className="flex items-center justify-center gap-4">
        <Input
          id="awayScore"
          type="number"
          min="0"
          value={awayScore}
          onChange={(e) => onAwayScoreChange(parseInt(e.target.value) || 0)}
          className="w-16 text-center"
        />
        <TeamColorSelector
          team="away"
          value={awayTeamColor}
          onChange={onAwayTeamColorChange}
          compact={true}
        />
      </div>
    </div>
  );
};