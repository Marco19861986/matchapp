import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Match } from "@/types/match";
import { Player } from "@/types/player";
import { startOfDay } from "date-fns";

interface TopPlayersProps {
  players: Player[];
}

interface PlayerPerformance {
  player: Player;
  averageRating: number;
}

export const TopPlayers = ({ players }: TopPlayersProps) => {
  const savedMatches = localStorage.getItem('football-manager-matches');
  const matches: Match[] = savedMatches 
    ? JSON.parse(savedMatches, (key, value) => {
        if (key === 'date') return new Date(value);
        return value;
      })
    : [];

  const recentMatches = matches
    .sort((a, b) => startOfDay(new Date(b.date)).getTime() - startOfDay(new Date(a.date)).getTime())
    .slice(0, 3);

  const playerPerformances: PlayerPerformance[] = players.map(player => {
    const matchesPlayed = recentMatches.filter(match => 
      match.players.some(p => p.id === player.id && p.rating)
    );

    const totalRating = matchesPlayed.reduce((sum, match) => {
      const playerInMatch = match.players.find(p => p.id === player.id);
      return sum + (playerInMatch?.rating || 0);
    }, 0);

    const averageRating = matchesPlayed.length > 0 
      ? totalRating / matchesPlayed.length 
      : 0;

    return {
      player,
      averageRating
    };
  });

  const topPlayers = playerPerformances
    .sort((a, b) => b.averageRating - a.averageRating)
    .slice(0, 3);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-2xl font-bold">
          Jugadores más en forma del momento
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {topPlayers.map((performance, index) => (
            <div 
              key={performance.player.id}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center gap-4">
                <span className="text-2xl font-bold text-gray-400">
                  #{index + 1}
                </span>
                <div>
                  <h3 className="font-semibold">{performance.player.name}</h3>
                </div>
              </div>
              <div className="text-right">
                <span className="text-lg font-bold">
                  {performance.averageRating.toFixed(1)}
                </span>
                <p className="text-sm text-gray-500">Nota media</p>
              </div>
            </div>
          ))}
          {topPlayers.length === 0 && (
            <p className="text-center text-gray-500">
              No hay suficientes datos de partidos recientes para mostrar estadísticas
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};