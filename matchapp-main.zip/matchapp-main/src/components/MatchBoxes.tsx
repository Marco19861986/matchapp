import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "./ui/card";
import { Calendar, Clock, MapPin, ArrowRight, CheckCircle } from "lucide-react";
import { addDays, format, isWednesday, isSunday, startOfDay, setHours, setMinutes } from "date-fns";
import { es } from 'date-fns/locale';
import { Match } from "@/types/match";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "./ui/hover-card";

const getNextMatchDate = () => {
  let currentDate = new Date();
  let daysToAdd = 0;

  // If it's after today's match time, look for the next match day
  if (isWednesday(currentDate)) {
    const matchTime = setHours(setMinutes(currentDate, 0), 22);
    if (currentDate > matchTime) {
      daysToAdd = isSunday(addDays(currentDate, 1)) ? 1 : 4;
    }
  } else if (isSunday(currentDate)) {
    const matchTime = setHours(setMinutes(currentDate, 0), 9);
    if (currentDate > matchTime) {
      daysToAdd = isWednesday(addDays(currentDate, 1)) ? 1 : 3;
    }
  } else {
    // Find next Wednesday or Sunday
    while (!isWednesday(addDays(currentDate, daysToAdd)) && 
           !isSunday(addDays(currentDate, daysToAdd))) {
      daysToAdd++;
    }
  }

  const nextMatchDate = addDays(currentDate, daysToAdd);
  if (isWednesday(nextMatchDate)) {
    return setHours(setMinutes(nextMatchDate, 0), 22);
  } else {
    return setHours(setMinutes(nextMatchDate, 0), 9);
  }
};

interface MatchBoxesProps {
  lastMatch?: Match;
}

export const MatchBoxes = ({ lastMatch }: MatchBoxesProps) => {
  const navigate = useNavigate();
  const nextMatchDate = getNextMatchDate();

  const getTeamColor = (isHome: boolean) => {
    return isHome ? "team-red" : "team-blue";
  };

  const getTeamName = (isHome: boolean) => {
    return isHome ? "Equipo Rojo" : "Equipo Azul";
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <HoverCard>
        <HoverCardTrigger asChild>
          <Card 
            className="cursor-pointer hover:shadow-lg transition-all duration-300 hover:scale-105"
            onClick={() => navigate('/alineacion')}
          >
            <CardContent className="p-6 space-y-4">
              <h2 className="text-2xl font-bold text-primary">Próximo Partido</h2>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Calendar className="w-4 h-4" />
                  <span>{format(nextMatchDate, "EEEE d 'de' MMMM", { locale: es })}</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  <span>{format(nextMatchDate, "HH:mm")} - {format(addDays(nextMatchDate, 1), "HH:mm")}</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  <span>Polideportivo del Arroyo de la Miel</span>
                </div>
              </div>
              <div className="flex items-center justify-end text-primary">
                <span className="text-sm">Gestionar alineación</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </div>
            </CardContent>
          </Card>
        </HoverCardTrigger>
        <HoverCardContent className="w-80">
          <p>Haz clic para gestionar la alineación del próximo partido</p>
        </HoverCardContent>
      </HoverCard>

      {lastMatch && (
        <HoverCard>
          <HoverCardTrigger asChild>
            <Card 
              className="cursor-pointer hover:shadow-lg transition-all duration-300 hover:scale-105"
              onClick={() => navigate(`/partidos/${lastMatch.id}`)}
            >
              <CardContent className="p-6 space-y-4">
                <h2 className="text-2xl font-bold text-primary">Último Partido</h2>
                <div className="space-y-4">
                  <div className="flex items-center justify-center gap-6 p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl shadow-md">
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full bg-team-red`} />
                      <span className="text-lg font-medium">{getTeamName(true)}</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-4xl font-bold text-team-red">{lastMatch.homeScore}</span>
                      <span className="text-2xl font-medium text-gray-400">-</span>
                      <span className="text-4xl font-bold text-team-blue">{lastMatch.awayScore}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full bg-team-blue`} />
                      <span className="text-lg font-medium">{getTeamName(false)}</span>
                    </div>
                  </div>
                  <p className="text-muted-foreground text-center">
                    {format(new Date(lastMatch.date), "d 'de' MMMM", { locale: es })}
                  </p>
                </div>
                <div className="flex items-center justify-end text-primary">
                  <span className="text-sm">Ver detalles</span>
                  <ArrowRight className="w-4 h-4 ml-1" />
                </div>
              </CardContent>
            </Card>
          </HoverCardTrigger>
          <HoverCardContent className="w-80">
            <p>Haz clic para ver todos los detalles del último partido</p>
          </HoverCardContent>
        </HoverCard>
      )}
    </div>
  );
};