import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface TeamColorSelectorProps {
  team: "home" | "away";
  value: string;
  onChange: (value: string) => void;
  compact?: boolean;
}

export const TeamColorSelector = ({ team, value, onChange, compact = false }: TeamColorSelectorProps) => {
  const getTeamName = (color: string) => {
    switch (color) {
      case "red":
        return "Rojos";
      case "blue":
        return "Azules";
      case "green":
        return "Verde";
      default:
        return color;
    }
  };

  return (
    <div className="flex items-center gap-2">
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className={compact ? "w-[90px]" : "w-[120px]"}>
          <SelectValue placeholder="Color" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="red">Rojos</SelectItem>
          <SelectItem value="blue">Azules</SelectItem>
          <SelectItem value="green">Verde</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
};