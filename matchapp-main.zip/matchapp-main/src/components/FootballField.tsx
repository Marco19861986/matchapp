import { Player } from "@/types/player";
import { useIsMobile } from "@/hooks/use-mobile";

interface FootballFieldProps {
  homeTeamColor: string;
  awayTeamColor: string;
  players: { [key: string]: Player };
  onResetPlayers: () => void;
  onPlayerClick?: (position: string, player: Player) => void;
}

export const FootballField = ({ 
  homeTeamColor, 
  awayTeamColor, 
  players,
  onPlayerClick,
  onResetPlayers
}: FootballFieldProps) => {
  const isMobile = useIsMobile();
  
  const getPositionText = (position: string) => {
    if (position.includes('gk')) return 'Portero';
    if (position.includes('def')) return `Def ${position.slice(-1)}`;
    if (position.includes('mid')) return `Med ${position.slice(-1)}`;
    return 'Del';
  };

  const PlayerCircle = ({ position, isHome }: { position: string, isHome: boolean }) => (
    <div className="flex flex-col items-center justify-center text-center">
      <span 
        className={`
          ${isMobile ? 'min-w-20 text-sm px-2' : 'min-w-24 px-3'} 
          py-1.5
          text-center 
          font-semibold 
          bg-white/90 
          rounded-md 
          z-20 
          shadow-[0_2px_4px_rgba(0,0,0,0.2),0_0_2px_rgba(0,0,0,0.3)] 
          text-black
          drop-shadow-[0_1px_1px_rgba(0,0,0,0.5)]
          truncate
          max-w-[140px]
          mx-auto
          cursor-pointer
          hover:bg-white
          active:scale-95
          transition-all
        `}
        onClick={() => {
          const player = players[position];
          if (player && onPlayerClick) {
            onPlayerClick(position, player);
          }
        }}
      >
        {players[position]?.name || getPositionText(position)}
      </span>
    </div>
  );

  return (
    <div className="relative flex flex-col items-center gap-4">
      <div className={`w-full max-w-3xl ${isMobile ? 'aspect-[1.8/3]' : 'aspect-[1/2]'} bg-field-grass rounded-xl relative p-4 my-8 shadow-xl border border-white/10 overflow-hidden`}>
        {/* Campo texture */}
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgdmlld0JveD0iMCAwIDQwIDQwIj48cGF0aCBkPSJNMCAwaDQwdjQwSDB6IiBmaWxsPSJub25lIi8+PHBhdGggZD0iTTAgMGg0MHY0MEgweiIgZmlsbD0iIzJFN0QzMiIvPjxwYXRoIGQ9Ik0wIDBoNDB2NDBIMHoiIGZpbGw9IiMyNjZBMjkiIG9wYWNpdHk9IjAuMiIvPjwvc3ZnPg==')] opacity-30" />

        {/* Porterías */}
        <div className="absolute top-2 left-1/2 w-16 h-4 border-2 border-field-lines -translate-x-1/2" />
        <div className="absolute bottom-2 left-1/2 w-16 h-4 border-2 border-field-lines -translate-x-1/2" />

        {/* Línea de medio campo */}
        <div className="absolute top-1/2 left-0 w-full h-[2px] bg-field-lines" />
        
        {/* Círculo central */}
        <div className="absolute top-1/2 left-1/2 w-24 h-24 border-2 border-field-lines rounded-full -translate-x-1/2 -translate-y-1/2" />

        {/* Areas */}
        <div className="absolute top-0 left-1/2 w-32 h-16 border-2 border-field-lines -translate-x-1/2" />
        <div className="absolute bottom-0 left-1/2 w-32 h-16 border-2 border-field-lines -translate-x-1/2" />

        {/* Equipo Local (Abajo) */}
        <div className="absolute bottom-0 left-0 w-full h-1/2 p-8">
          <div className="relative w-full h-full">
            {/* Portero */}
            <div className={`absolute ${isMobile ? 'bottom-0' : 'bottom-[3%]'} left-1/2 -translate-x-1/2`}>
              <PlayerCircle position="home-gk" isHome={true} />
            </div>
            
            {/* Defensas */}
            <div className={`absolute ${isMobile ? 'bottom-[23%]' : 'bottom-[22%]'} left-0 w-full flex justify-center gap-4 md:gap-8 px-4`}>
              {[1, 2, 3].map((i) => (
                <div key={i}>
                  <PlayerCircle position={`home-def-${i}`} isHome={true} />
                </div>
              ))}
            </div>
            
            {/* Mediocampistas */}
            <div className={`absolute ${isMobile ? 'bottom-[49%]' : 'bottom-[47%]'} left-0 w-full flex justify-center gap-4 md:gap-8 px-4`}>
              {[1, 2, 3].map((i) => (
                <div key={i}>
                  <PlayerCircle position={`home-mid-${i}`} isHome={true} />
                </div>
              ))}
            </div>
            
            {/* Delantero */}
            <div className={`absolute ${isMobile ? 'bottom-[75%]' : 'bottom-[72%]'} left-1/2 -translate-x-1/2`}>
              <PlayerCircle position="home-fw" isHome={true} />
            </div>
          </div>
        </div>

        {/* Equipo Visitante (Arriba) */}
        <div className="absolute top-0 left-0 w-full h-1/2 p-8">
          <div className="relative w-full h-full">
            {/* Portero */}
            <div className={`absolute ${isMobile ? 'top-[2%]' : 'top-[5%]'} left-1/2 -translate-x-1/2`}>
              <PlayerCircle position="away-gk" isHome={false} />
            </div>
            
            {/* Defensas */}
            <div className={`absolute ${isMobile ? 'top-[28%]' : 'top-[25%]'} left-0 w-full flex justify-center gap-4 md:gap-8 px-4`}>
              {[1, 2, 3].map((i) => (
                <div key={i}>
                  <PlayerCircle position={`away-def-${i}`} isHome={false} />
                </div>
              ))}
            </div>
            
            {/* Mediocampistas */}
            <div className={`absolute ${isMobile ? 'top-[54%]' : 'top-[50%]'} left-0 w-full flex justify-center gap-4 md:gap-8 px-4`}>
              {[1, 2, 3].map((i) => (
                <div key={i}>
                  <PlayerCircle position={`away-mid-${i}`} isHome={false} />
                </div>
              ))}
            </div>
            
            {/* Delantero */}
            <div className={`absolute ${isMobile ? 'top-[80%]' : 'top-[75%]'} left-1/2 -translate-x-1/2`}>
              <PlayerCircle position="away-fw" isHome={false} />
            </div>
          </div>
        </div>
      </div>

      {/* Save button - Outside the field */}
      <button
        onClick={onResetPlayers}
        className="bg-white/90 text-black px-6 py-2 rounded-md shadow-lg hover:bg-white/100 transition-colors font-medium"
      >
        Salva partido
      </button>
    </div>
  );
};