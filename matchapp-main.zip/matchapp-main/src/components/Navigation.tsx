import { Link } from "react-router-dom";
import { Users, BarChart2, Calendar, Home } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

export const Navigation = () => {
  const isMobile = useIsMobile();

  return (
    <nav className={`${isMobile ? 'grid grid-cols-2 gap-2' : 'flex gap-4'} p-4 bg-white rounded-lg shadow-sm mb-4`}>
      <Link
        to="/"
        className="flex items-center gap-2 px-4 py-2 text-sm font-bold uppercase tracking-wide text-gray-700 hover:text-gray-900 transition-colors font-heading"
      >
        <Home className="w-4 h-4" />
        <span>Home</span>
      </Link>
      <Link
        to="/alineacion"
        className="flex items-center gap-2 px-4 py-2 text-sm font-bold uppercase tracking-wide text-gray-700 hover:text-gray-900 transition-colors font-heading"
      >
        <Users className="w-4 h-4" />
        <span>Alineación</span>
      </Link>
      <Link
        to="/estadisticas"
        className="flex items-center gap-2 px-4 py-2 text-sm font-bold uppercase tracking-wide text-gray-700 hover:text-gray-900 transition-colors font-heading"
      >
        <BarChart2 className="w-4 h-4" />
        <span>Estadísticas</span>
      </Link>
      <Link
        to="/partidos"
        className="flex items-center gap-2 px-4 py-2 text-sm font-bold uppercase tracking-wide text-gray-700 hover:text-gray-900 transition-colors font-heading"
      >
        <Calendar className="w-4 h-4" />
        <span>Partidos</span>
      </Link>
    </nav>
  );
};