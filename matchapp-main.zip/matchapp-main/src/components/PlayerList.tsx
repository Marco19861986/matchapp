import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Player, PlayerPosition, PLAYER_LIMITS, createDefaultStats } from "@/types/player";
import { Card, CardContent } from "./ui/card";
import { cn } from "@/lib/utils";
import { Pencil } from "lucide-react";
import { useState } from "react";

interface PlayerListProps {
  players: Player[];
  onPlayerSelect: (player: Player) => void;
  onReset: () => void;
  onAddPlayer: (player: Player) => void;
  onUpdatePlayerName: (playerId: string, name: string) => void;
  selectedPlayers?: { [key: string]: Player };
}

export const PlayerList = ({ 
  players, 
  onPlayerSelect, 
  onReset, 
  onAddPlayer,
  onUpdatePlayerName,
  selectedPlayers = {} 
}: PlayerListProps) => {
  const [editingPlayerId, setEditingPlayerId] = useState<string | null>(null);

  const addPlayer = (position: PlayerPosition) => {
    const positionCount = players.filter(p => p.position === position).length;
    if (positionCount >= PLAYER_LIMITS[position]) return;

    const newPlayer: Player = {
      id: crypto.randomUUID(),
      name: '',
      position,
      stats: createDefaultStats(position)
    };
    onAddPlayer(newPlayer);
    setEditingPlayerId(newPlayer.id);
  };

  const handleReset = () => {
    onReset();
    setEditingPlayerId(null);
  };

  const isPlayerSelected = (playerId: string) => {
    return Object.values(selectedPlayers || {}).some(p => p.id === playerId);
  };

  const handleEditClick = (playerId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingPlayerId(playerId);
  };

  const handleInputBlur = () => {
    setEditingPlayerId(null);
  };

  const renderPositionSection = (position: PlayerPosition, title: string) => {
    const positionPlayers = players.filter(p => p.position === position);
    const canAdd = positionPlayers.length < PLAYER_LIMITS[position];

    return (
      <div className="space-y-1">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold font-heading">{title}</h3>
          {canAdd && (
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => addPlayer(position)}
            >
              Añadir
            </Button>
          )}
        </div>
        <div className="space-y-2 overflow-y-auto">
          {positionPlayers.map(player => (
            <div 
              key={player.id} 
              className={cn(
                "relative group flex gap-3 items-center", // Increased gap from 1 to 3
                isPlayerSelected(player.id) && "opacity-50"
              )}
            >
              <Button
                variant="ghost"
                size="icon"
                className="h-5 w-5 shrink-0" // Reduced from h-6 w-6 to h-5 w-5
                onClick={(e) => handleEditClick(player.id, e)}
              >
                <Pencil className="h-2.5 w-2.5" /> {/* Reduced from h-3 w-3 to h-2.5 w-2.5 */}
              </Button>
              <Input
                value={player.name}
                onChange={(e) => onUpdatePlayerName(player.id, e.target.value)}
                placeholder="Nombre"
                className={cn(
                  "cursor-pointer hover:ring-2 hover:ring-primary transition-all text-sm h-7",
                  isPlayerSelected(player.id) && "bg-gray-100",
                  editingPlayerId !== player.id && "cursor-pointer"
                )}
                onClick={() => player.name && !editingPlayerId && onPlayerSelect(player)}
                readOnly={editingPlayerId !== player.id}
                onBlur={handleInputBlur}
                autoFocus={editingPlayerId === player.id}
              />
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <Card className="w-full">
      <CardContent className="space-y-4 pt-6">
        {renderPositionSection('goalkeeper', 'Porteros')}
        <div className="mt-2">
          {renderPositionSection('player', 'Jugadores')}
        </div>
      </CardContent>
    </Card>
  );
};